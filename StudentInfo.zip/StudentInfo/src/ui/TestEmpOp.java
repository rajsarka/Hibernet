package ui;

import bean.Stu;
import service.EmployeeServiceImpl;
import service.IEmployeeService;

public class TestEmpOp {

	public static void main(String[] args) {
		
		
		Stu e1=new Stu();
		Stu e2=new Stu();
		e1.setRollno(3);
		e1.setName("Rajib Sarkar");
		e1.setMarks(98.0F);
		
		e2.setRollno(4);
		e2.setName("Bimal dey");
		e2.setMarks(75.0F);
		
		IEmployeeService empSer=new EmployeeServiceImpl();
		empSer.addStud(e1);
		empSer.addStud(e2);

	}

}
