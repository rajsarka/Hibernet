package service;

import bean.Stu;

public interface IEmployeeService {

	
	public Stu addStud(Stu ee);
	
	public Stu getStudById(int studId);
	
	
}
