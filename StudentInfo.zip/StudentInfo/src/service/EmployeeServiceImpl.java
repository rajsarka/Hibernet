package service;

import bean.Stu;
import dao.EmployeeDaoImpl;
import dao.IEmployeeDao;

public class EmployeeServiceImpl implements IEmployeeService {

	
	IEmployeeDao empDao=null;
	public EmployeeServiceImpl()
	{
		empDao=new EmployeeDaoImpl();
	}
	
	@Override
	public Stu addStud(Stu ee) {
		
		return empDao.addStud(ee);
	}

	@Override
	public Stu getStudById(int studId) {
		
		return empDao.getStudById(studId);
	}

}
