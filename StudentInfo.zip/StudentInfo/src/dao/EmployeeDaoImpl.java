package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import bean.Stu;
import util.JPAUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	
	
	EntityManager em=null;
	EntityTransaction tran=null;
	public EmployeeDaoImpl()
	{
		
	}

	
	@Override
	public Stu addStud(Stu st) {
		
		em=JPAUtil.getentityManager();
		//get tran object
		tran=em.getTransaction();
		//begin the tran
		tran.begin();
		em.persist(st);
		tran.commit();
		System.out.println("Data is inserted in the table");
		Stu e1=em.find(Stu.class,st.getRollno());
		return e1;
	}

	@Override
	public Stu getStudById(int studId) {
		
		return null;
	}

}
