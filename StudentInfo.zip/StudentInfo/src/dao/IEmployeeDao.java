package dao;
import bean.Stu;

public interface IEmployeeDao {

	
	public Stu addStud(Stu ee);
	
	public Stu getStudById(int studId);
	
}
