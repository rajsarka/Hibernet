



	package bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
	@Table(name="Student")
	public class Stu {

		
		
		@Id
		@Column(name="student_rollno",length=10)
		private int rollno;
		
		
		@Column(name="student_name",length=25)
		private String Name;
		
		
		@Column(name="student_marks",length=15)
		private float Marks;


		@Override
		public String toString() {
			return "Stu [rollno=" + rollno + ", Name=" + Name + ", Marks=" + Marks + "]";
		}


		public Stu() {
			super();
			
		}


		public int getRollno() {
			return rollno;
		}


		public void setRollno(int rollno) {
			this.rollno = rollno;
		}


		public String getName() {
			return Name;
		}


		public void setName(String name) {
			Name = name;
		}


		public float getMarks() {
			return Marks;
		}


		public void setMarks(float marks) {
			Marks = marks;
		}
	
	
}
