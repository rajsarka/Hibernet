package com.cg.demo.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.demo.bean.Emp;
import com.cg.demo.service.EmployeeServiceImpl;
import com.cg.demo.service.IEmployeeService;

public class TestEmpOp {

	public static void main(String[] args) {
		
		IEmployeeService empSer=new EmployeeServiceImpl();
		String empname;
		float empsal;
		int empid;
	
		Scanner sc=new Scanner(System.in);
		int option;
		
		
do {
			Emp e=new Emp();
			
			

			System.out.println("1. Add Employee");
			System.out.println("2.Get employee");
			System.out.println("3.Delete Employee");
			System.out.println("4.Fetch All Records");
			System.out.println("5.Update Salary");
			System.out.println("6.Exit");
			option=sc.nextInt();
			
	switch(option)
	{
		case 1://add employee
		
			
			/*System.out.println("Enter Employee Id");
			empid=sc.nextInt();*/
			
			System.out.println("Enter employee name");
			empname=sc.next();
			System.out.println("Enter Salary of Employee");
			empsal=sc.nextFloat();
			e.setEmpName(empname);
			e.setEmpSal(empsal);
			 e=empSer.addEmp(e);
			System.out.println("Employee details of Employee Id: " +e.getEmpId()+ " added successfully");
		break;
		
		
		case 2:  //get employee
		
			System.out.println("Enter Employee Id whose details want to display");
			empid=sc.nextInt();
			Emp emp2=empSer.getEmpById(empid);
			System.out.println(emp2);
			if(emp2==null)
			{
				System.out.println("data deleted");
			}
			break;
			
		
		
		case 3: //delete employee
		
			System.out.println("Enter Employee Id whose details want to delete");
			empid=sc.nextInt();
			Emp emp3=empSer.deleteEmpById(empid);
			System.out.println(emp3.getEmpId()+ " details deleted");
			break;
		
		
		case 4:
		
			ArrayList<Emp> eList =empSer.fetchAllEmp();
			for(Emp tempEmp:eList)
			{
				System.out.println("ID: "+tempEmp.getEmpId()+" / Name : "+tempEmp.getEmpName()+"/ Salary : "+tempEmp.getEmpSal()+"/doj : "+tempEmp.getEmpDOJ());
			}
		
		case 5:
			System.out.println("Enter Employee Id whose Salary want to Update");
			empid=sc.nextInt();
			System.out.println("Enter increased salary");
			empsal=sc.nextInt();
			Emp ee3=empSer.updateEmpSal(empid, empsal);
			System.out.println("Updated Salry: " +ee3.getEmpSal());
	}
	

}while(option!=6);

		
		
}
}

	

		