package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Emp;

public interface IEmployeeService {

	
	public Emp addEmp(Emp ee);
	
	public Emp getEmpById(int empId);
	
	public Emp deleteEmpById(int empId);
	
	public ArrayList<Emp> fetchAllEmp();

	public Emp updateEmpSal(int empid, float newSal);
}
