package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Emp;
import com.cg.demo.dao.EmployeeDaoImpl;
import com.cg.demo.dao.IEmployeeDao;

public class EmployeeServiceImpl implements IEmployeeService {

	
	IEmployeeDao empDao=null;
	public EmployeeServiceImpl()
	{
		empDao=new EmployeeDaoImpl();
	}
	
	@Override
	public Emp addEmp(Emp ee) {
		
		return empDao.addEmp(ee);
	}

	@Override
	public Emp getEmpById(int empId) {
		
		return empDao.getEmpById(empId);
	}

	@Override
	public Emp deleteEmpById(int empId) {
		
		return empDao.deleteEmpById(empId);
	}

	@Override
	public ArrayList<Emp> fetchAllEmp() {
		
			return empDao.fetchAllEmp();
	}

	@Override
	public Emp updateEmpSal(int empid, float newSal) {
		
		return empDao.updateEmpSal(empid,newSal);
	}

}
