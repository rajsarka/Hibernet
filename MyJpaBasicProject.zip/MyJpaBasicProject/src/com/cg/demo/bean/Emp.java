package com.cg.demo.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Employee")
public class Emp {

	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="emp_id",length=150)
	private int empId;
	
	
	@Column(name="emp_name",length=200)
	private String empName;
	
	
	@Column(name="emp_sal",length=200)
	private float empSal;
	
	@Column(name="emp_doj")
	@Temporal(TemporalType.DATE)
	//@Transient
	private Date empDOJ;
	
	

	public Date getEmpDOJ() {
		return empDOJ;
	}

	public void setEmpDOJ(Date empDOJ) {
		this.empDOJ = empDOJ;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	public Emp() {
		super();
		
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empname=" + empName + ", empsal=" + empSal + "]";
	}
	
	
	
	
	
	
	
}
