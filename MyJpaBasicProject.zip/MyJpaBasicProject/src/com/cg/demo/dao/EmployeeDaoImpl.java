package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.demo.bean.Emp;
import com.cg.demo.util.JPAUtil;

public class EmployeeDaoImpl implements IEmployeeDao {
	
	
	
	EntityManager em=null;
	EntityTransaction tran=null;
	public EmployeeDaoImpl()
	{
		
	}

	
	@Override
	public Emp addEmp(Emp emp) {
		
		em=JPAUtil.getentityManager();
		
		//get tran object
		tran=em.getTransaction();
		
		//begin the tran
		tran.begin();
		
		em.persist(emp);
		tran.commit();
		System.out.println("Data is inserted in the table");
		Emp e1=em.find(Emp.class,emp.getEmpId());
		return e1;
	}

	@Override
	public Emp getEmpById(int empId) {
		em=JPAUtil.getentityManager();
		Emp e1=em.find(Emp.class, empId);
		return e1;
	}


	@Override
	public Emp deleteEmpById(int empId) {
		em=JPAUtil.getentityManager();
		Emp ee=em.find(Emp.class, empId);
		tran=em.getTransaction();
		tran.begin();
		em.remove(ee);
		tran.commit();
		return ee;
	}

	@Override
	public ArrayList<Emp> fetchAllEmp() 
	{
		String myQry="SELECT emps FROM Emp emps "; 
		//where emps.empSal between 40000 and 70000
		em=JPAUtil.getentityManager();
		TypedQuery<Emp> tyQry=em.createQuery(myQry, Emp.class);
		ArrayList<Emp> empList=(ArrayList)tyQry.getResultList();
		
		return empList;
	}


	@Override
	public Emp updateEmpSal(int empid, float newSal) 
	{
		float updatedSal=0;
		em=JPAUtil.getentityManager();
		tran=em.getTransaction();
		Emp emp1=em.find(Emp.class, empid);
		updatedSal=emp1.getEmpSal()+newSal;
		emp1.setEmpSal(updatedSal);
		tran.begin();
		em.merge(emp1);
		tran.commit();
		System.out.println("Salary is Updated for:"+empid);
		
		return emp1;
	}
}
