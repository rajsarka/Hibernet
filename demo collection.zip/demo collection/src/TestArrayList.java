import java.util.ArrayList;

public class TestArrayList {

	public static void main(String args[]) {
//		ArrayList<Integer> list=new ArrayList<Integer>();
//		list.add(50);
//		list.add(20);
//		list.add(10);
//		System.out.println(list);
		
		ArrayList<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(81,"Rajib"));
		list.add(new Employee(20,"Raju"));
	}
}
