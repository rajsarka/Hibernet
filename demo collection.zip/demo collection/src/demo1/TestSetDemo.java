package demo1;

import java.util.HashSet;

public class TestSetDemo {
	public static void main(String args[]) {
		
		HashSet<Employee> list=new HashSet<Employee>();
		
		list.add(new Employee(81,"Rajib"));
		list.add(new Employee(81,"Rajib"));
		list.add(new Employee(81,"Rajib"));
	}
}
