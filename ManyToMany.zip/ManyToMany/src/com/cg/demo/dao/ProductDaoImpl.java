package com.cg.demo.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.demo.bean.Order;
import com.cg.demo.util.JPAUtil;

public class ProductDaoImpl {
EntityManager em=null;
EntityTransaction tran=null;

public ProductDaoImpl()
{
	em=JPAUtil.getentityManager();
	tran=em.getTransaction();
}


public void addOrder(Order order)
{
	tran.begin();
	em.persist(order);
	tran.commit();
	System.out.println("Order Info is inserted");
	
}



public ArrayList<Order> getAllOrders()
{
TypedQuery<Order> tq=em.createQuery("SELECT ords FROM Order ords",Order.class);	
ArrayList ordList=(ArrayList<Order>)tq.getResultList();	
	return ordList;
}












}
