package com.cg.demo.ui;

import java.util.Date;
import java.util.HashSet;

import com.cg.demo.bean.Order;
import com.cg.demo.bean.Product;
import com.cg.demo.dao.ProductDaoImpl;

public class TestProductOrder {
 public static void main(String args[]) {
	Product elecProduct= new Product();
	elecProduct.setProductName("LED TV");
	elecProduct.setProductPrice(45000);

	Product beautyProduct = new Product();
	beautyProduct.setProductName("Face Wash");
	beautyProduct.setProductPrice(80);

	Product babyProduct = new Product();
    babyProduct.setProductName("Pampers");
	babyProduct.setProductPrice(15);

	Product eleProduct = new Product();

	eleProduct.setProductName("CFL Bulb");
	eleProduct.setProductPrice(250);
	System.out.println("----------------");
	
	
	// now define first order and add few products in it
			Order firstOrder = new Order();
			
			HashSet<Product> firstOrderProdSet=new HashSet();
			firstOrderProdSet.add(elecProduct);
			firstOrderProdSet.add(babyProduct);
			firstOrderProdSet.add(beautyProduct);
			
			
			firstOrder.setOrderDate(new Date());
			firstOrder.setProductSet(firstOrderProdSet);

			ProductDaoImpl dao=new ProductDaoImpl();
			//dao.addOrder(firstOrder);
			System.out.println("----------------");
	
	// now define second order and add few products in it
			Order secondOrder = new Order();
			HashSet<Product> secondOrderProdSet=new HashSet();
			secondOrderProdSet.add(beautyProduct);		
			secondOrderProdSet.add(eleProduct);
			secondOrderProdSet.add(beautyProduct);
			
			
			secondOrder.setOrderDate(new Date());
			secondOrder.setProductSet(secondOrderProdSet);		
			dao.addOrder(secondOrder);
			System.out.println("----------------");
 }
	
}
