package com.cg.demo.bean;

import javax.persistence.Column;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="Employee")
public class Emp {

	
	
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="mySeq")
	@SequenceGenerator(name="mySeq",sequenceName="vai_emp_seq2",allocationSize=1)
	
	@Column(name="emp_id",length=10)
	private int empId;
	
	
	@Column(name="emp_name",length=25)
	private String empName;
	
	
	@Column(name="emp_sal",length=15)
	private float empSal;
	
	@Column(name="emp_doj")
	@Temporal(TemporalType.DATE)
	//@Transient
	private Date empDOJ;
	
	

	public Date getEmpDOJ() {
		return empDOJ;
	}

	public void setEmpDOJ(Date empDOJ) {
		this.empDOJ = empDOJ;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}

	public Emp() {
		super();
		
	}

	@Override
	public String toString() {
		return "Emp [empId=" + empId + ", empname=" + empName + ", empsal=" + empSal + "]";
	}
	
	
	
	
	
	
	
}
