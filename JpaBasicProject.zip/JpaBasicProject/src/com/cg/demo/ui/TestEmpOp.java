package com.cg.demo.ui;


import java.util.ArrayList;
import java.util.Date;

import com.cg.demo.bean.Emp;
import com.cg.demo.service.EmployeeServiceImpl;
import com.cg.demo.service.IEmployeeService;

public class TestEmpOp {

	public static void main(String[] args) {
		
		IEmployeeService empSer=new EmployeeServiceImpl();
		Emp e1=new Emp();
		
		//e1.setEmpId(11200);
		e1.setEmpName("putu manna");
		e1.setEmpSal(4500.0F);
		e1.setEmpDOJ(new Date());;
		empSer.addEmp(e1);
		
//		/****************/
//		Emp e2=new Emp();
//		//e2.setEmpId(11207);
//		e2.setEmpName("p dey");
//		e2.setEmpSal(49000.0F);
//		empSer.addEmp(e2);
//		
//		/******************/
//		Emp e3=new Emp();
//		//e3.setEmpId(11207);
//		e3.setEmpName("m dey");
//		e3.setEmpSal(69000.0F);
//		empSer.addEmp(e3);
	
	/********fetch data for empid=122***********/
//		Emp ee=empSer.getEmpById(1);
//		System.out.println(ee);
		
		/******delete data for empid=1*****/
		/*Emp ee2=empSer.deleteEmpById(11206);
		System.out.println(ee2.getEmpId()+" is deleted from the table");*/
		
		/******Fetch all records**********/
		
		ArrayList<Emp> eList =empSer.fetchAllEmp();
		for(Emp tempEmp:eList)
		{
			System.out.println("ID: "+tempEmp.getEmpId()+" / Name : "+tempEmp.getEmpName()+"/ Salary : "+tempEmp.getEmpSal()+"/doj : "+tempEmp.getEmpDOJ());
		}
	/********Update Salary*****/
//		Emp ee3=empSer.updateEmpSal(1, 5000);
//		System.out.println("Updated Salry: " +ee3);
		
		
	}

}
