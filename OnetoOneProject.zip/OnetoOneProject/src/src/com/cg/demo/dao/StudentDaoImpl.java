package src.com.cg.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import src.com.cg.demo.bean.Address;
import src.com.cg.demo.bean.Stud;
import src.com.cg.demo.util.JPAUtil;

public class StudentDaoImpl {

	EntityManager em=null;
	EntityTransaction trans=null;
	
	public StudentDaoImpl()
	{
		
	}
	
	public Stud addStudent(Stud stu)
	{
		
		em=JPAUtil.getentityManager();
		trans=em.getTransaction();
		trans.begin();
		em.persist(stu);
		trans.commit();
		Stud st=em.find(Stud.class, stu.getRollNo());
		return st;
		
	}
	
	public Stud delStu(int rn)
	{
		em=JPAUtil.getentityManager();
		trans=em.getTransaction();
		
		trans.begin();
		Stud st=em.find(Stud.class, rn);
		em.remove(st);
		trans.commit();
		Stud deleteStu=em.find(Stud.class, rn);
		return deleteStu;
	}
	
	
	public Address delAddress(int addId)
	{
		em=JPAUtil.getentityManager();
		trans=em.getTransaction();
		
		trans.begin();
		Address ad=em.find(Address.class, addId);
		em.remove(ad);
		trans.commit();
		Address deletedAdd=em.find(Address.class, addId);
		return deletedAdd;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
