package src.com.cg.demo.ui;

import java.util.Scanner;


import src.com.cg.demo.bean.Stud;
import src.com.cg.demo.bean.Address;
import src.com.cg.demo.dao.StudentDaoImpl;

public class TestStuDemo {

	public static void main(String args[]) {

//Scanner sc=new Scanner(System.in);
//
//System.out.println("Enter Name: ");
//String nm=sc.next();
//System.out.println("Enter Street: ");
//String str=sc.next();
//System.out.println("Enter City: ");
//String ct=sc.next();	
//System.out.println("Enter State: ");
//String st=sc.next();
//System.out.println("Enter Zipcode: ");
//String zp=sc.next();
//	
//	Address ad1=new Address(str,ct,st,zp);
//	Stud st1=new Stud(nm,ad1);
//	
	StudentDaoImpl stuDao=new StudentDaoImpl();
//	Stud tempSt=stuDao.addStudent(st1);
//	System.out.println("Data Added "+ tempSt);
	
	//*********************************//
	
	
//	System.out.println("*********Delete base on roll no*********");
//	Stud tempSt2=stuDao.delStu(48);
//	if(tempSt2==null)
//	{
//		System.out.println("Data is  deleted ");
//	}
//	else {
//		System.out.println("Data is  not deleted");
//	}
	
	//***********************************//
	
	System.out.println("*********Delete base on address id*********");
	Address tempSt3=stuDao.delAddress(43);
	if(tempSt3==null)
	{
		System.out.println("Data is  deleted ");
	}
	else {
		System.out.println("Data is  not deleted");
	}
	
	}

}
