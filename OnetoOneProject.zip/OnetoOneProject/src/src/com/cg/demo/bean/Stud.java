package src.com.cg.demo.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="students")
public class Stud {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="studentId",length=15)
	private int rollNo;
	
	@Column(name="name",length=30)
	private String stuName;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="address_id")
	private Address stuAddress;

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public Address getStuAddress() {
		return stuAddress;
	}

	public void setStuAddress(Address stuAddress) {
		this.stuAddress = stuAddress;
	}

	@Override
	public String toString() {
		return "Stud [rollNo=" + rollNo + ", stuName=" + stuName + ", stuAddress=" + stuAddress + "]";
	}

	public Stud() {
	
		
	}

	public Stud(String stuName, Address stuAddress) {
		super();
	
		this.stuName = stuName;
		this.stuAddress = stuAddress;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
