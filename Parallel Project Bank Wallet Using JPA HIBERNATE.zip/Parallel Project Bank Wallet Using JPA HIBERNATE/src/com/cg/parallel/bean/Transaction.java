package com.cg.parallel.bean;


import java.sql.Date;

//import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="Transaction_table")
public class Transaction {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="tran_id",length=10)
	public long transactionid;
	@Column(name="mob_no",length=10)
	public String mobno;
	@Column(name="cus_amt",length=10)
	public Long amount;
	@Column(name="tran_type",length=10)
	public String trantype;
	@Column(name="tran_date")
	//@Temporal(TemporalType.DATE)
	public  Date tranDate;
	
	public long getTransactionid() {
		return transactionid;
	}
	public void setTransactionid(long transactionid) {
		this.transactionid = transactionid;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public Long getAmount() {
		return amount;
	}
	public void setAmount(Long amount) {
		this.amount = amount;
	}
	public String getTrantype() {
		return trantype;
	}
	public void setTrantype(String trantype) {
		this.trantype = trantype;
	}


	public Date getTranDate() {
		return tranDate;
	}
	public void setTranDate(Date tranDate) {
		this.tranDate = tranDate;
	}
	
	@Override
	public String toString() {
		return "Transaction [transactionid=" + transactionid + ", mobno=" + mobno + ", amount=" + amount + ", trantype="
				+ trantype + ", tranDate=" + tranDate + "]";
	}
	
	public Transaction(long transactionid, String mobno, Long amount, String trantype, Date tranDate) {
		super();
		this.transactionid = transactionid;
		this.mobno = mobno;
		this.amount = amount;
		this.trantype = trantype;
		this.tranDate = tranDate;
	}
	public Transaction() {
		
	}
	
	
}
