package com.cg.parallel.pl;


import java.util.ArrayList;
import java.util.Scanner;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.exception.CustomerException;
import com.cg.parallel.service.CustomerService;
import com.cg.parallel.service.CustomerServiceImpl;
import com.cg.parallel.service.CustomerServiceValidator;




public class Main {

	public static void main(String args[]) 
	{
		
		Scanner sc= new Scanner(System.in);	
		
		CustomerService service =new CustomerServiceImpl();
		CustomerServiceValidator validator=new CustomerServiceValidator();
		int option;
	
		do {
			
			Customer cus =new Customer();
			
			System.out.println("1. Create Wallet Account");
			System.out.println("2. Show Customer Details");
			System.out.println("3. Show balance");
			System.out.println("4. Deposite Money");
			System.out.println("5. Withdraw Money");
			System.out.println("6. Fund Transfer");
			System.out.println("7. Print Transactions");
			System.out.println("8. Exit --> ");
			
			System.out.println("Choose option...->");
		 option =sc.nextInt();
		
		
		switch(option){	
		
		
//------------------------------Create Account--------------------------------//
case 1	:
			
			
			try {
	System.out.println("For Registration...\n Enter details...->");
	
	System.out.println("Enter your mobile no");
	String no =sc.next();
	if(validator.getValidateMobNo(no) == false)
		throw new CustomerException("Enter your Valid Phone number.( must be 10 digit)");
	
	System.out.println("Enter your name");
	String name =sc.next();
	if(validator.getValidateName(name) == false)
		throw new CustomerException("Customer Name start should be  Capital.(Name length should be 3-20 alphabet)");
	
	System.out.println("Enter your aadhar no");
	String aadhar =sc.next();
	
	System.out.println("Enter your Bank your Name ");
	String bankname =sc.next();
	if(validator.getValidateBankName(bankname)==false)
		throw new CustomerException("Invalid bank Name.");
	
	System.out.println("Enter your Bank account no with which want to link");
	String acc =sc.next();
	if(validator.getValidateAccNo(acc)==false)
		throw new CustomerException("Enter Your Valid Account No.Account no must be 6 digit.");
	
	System.out.println("Enter password");
	String pword =sc.next();
	if(validator.getValidatePassword(pword)==false)
		throw new CustomerException("Enter Correct Password Format.");
	
	
	
	cus.setMobileno(no);
	cus.setName(name);
	cus.setAadhar(aadhar);
	cus.setBankname(bankname);
	cus.setAccno(acc);
	cus.setPword(pword);
	
	
	cus=service.AddCustomer(cus);
	System.out.println("Payment Wallet with Mobile no. : " + cus.getMobileno()+"successfully created");
	}
	
	catch(CustomerException e)
	{
		System.out.println(e.getMessage());
	}
	
	break;
			
		
		
//------------------------------Show all customer List-------------------------//		
case 2:
		try {
				ArrayList<Customer> list= service.getCustomerList();
				for(Customer e : list)
				{
					System.out.println(e);
				}	
					
			}
		catch(CustomerException e) {
					System.out.println(e.getMessage());
				
				}
				break;
				
				
//------------------------------Show balance-------------------------------------------//			
			case 3:
				
			try {
				
				
				System.out.println("Enter your Mobile no:");
				String mobno = sc.next();
				Customer cust=service.getMobno(mobno);
		    if(cust==null) {
				throw new CustomerException("\n ---------------------\n Enter Correct Registered Mobile no..\n ---------------------\n");

				}
			else {	
				System.out.println("\n-----------------------\nEnter your Password");
				String pwd = sc.next();
					if(cust.getPword().equals(pwd))
					{	
					cus=service.showBalance(mobno);
					System.out.println("\n---------------------\nYour balance is:  "+ cus.getAmount()+"\n--------------------");
					}
					else {
						throw new CustomerException("\n ---------------------\n Enter Correct Password..\n ------------------------\n");
						
					}
				}
			}
			 
			catch (CustomerException e) {
				
				System.out.println(e.getMessage());
			}
				
				break;
				
			
//--------------------------------Deposite------------------------------------//			
case 4:
	
	
	try {
					
		System.out.println("Enter your Mobile no:");
		String mobno = sc.next();
		Customer cust=service.getMobno(mobno);
			 if(cust==null)
			    {
					throw new CustomerException("\n ---------------------\n Enter Correct Registered Mobile no..\n ---------------------\n");
			    }
			 else {
					System.out.println("Enter Amount Want To Deposite :");
					String amt = sc.next();
					
					cus = service.addMoney(mobno,Long.parseLong(amt));
				
					service.showBalance(cus.getMobileno());
					System.out.println("Your Balance "+ amt +" is credited. with registered Mobile no"+mobno);
			     }
		}
				
	catch (CustomerException e) {
		   System.out.println(e.getMessage());
		}
				
				
	break;
	

//---------------------------------------------Withdraw---------------------------------//	
case 5:
	try {
			System.out.println("Enter your mobile no");
			String mobno = sc.next();
			Customer cust=service.getMobno(mobno);
		    if(cust==null) {
				throw new CustomerException("\n ---------------------\n Enter Correct Registered Mobile no..\n ---------------------\n");

				}
			else {
			System.out.println("Enter your Password");
			String pwd = sc.next();
					if(cust.getPword().equals(pwd))
					{
			
						System.out.println("Enter Amount Want To withdraw :");
						String amt = sc.next();
						
						cus = service.withdraw(mobno, Long.parseLong(amt));
						
						service.showBalance(cus.getMobileno());
					}
					else {
						throw new CustomerException("\n ---------------------\n Enter Correct Password..\n ------------------------\n");
						
					}
			
		         } 
	}    catch (CustomerException e) {
		System.out.println(e.getMessage());
		}
			
		break;
//---------------------------------------------Fund Transfer---------------------------------//	

case 6:
				
try {
System.out.println("Enter Your Mobileno from which you want to Transfer fund:");
String mobno1 = sc.next();
Customer cust=service.getMobno(mobno1);
if(cust==null) {
throw new CustomerException("\n ---------------------\n Enter Correct Registered Mobile no of Sender..\n ---------------------\n");}
					
System.out.println("Enter your Password");
String pwd = sc.next();
if(cust.getPword().equals(pwd)) {
	System.out.println("Enter the Amount that you want to transfer .");
	String amt=sc.next();
			if(Long.parseLong(amt)<cust.getAmount())
			{
				System.out.println("Enter Mobile no. to which you want to Transfer fund:");
				String mobno2 = sc.next();
				Customer cust2=service.getMobno(mobno2);
				if(cust2==null) {
				throw new CustomerException("\n ---------------------\n Enter Correct Registered Mobile no of Receiver..\n ---------------------\n");}					
				service.fundTransfer(mobno1,mobno2,Long.parseLong(amt));
		    }
			else {
				System.out.println("Fund Transfer Failed !! Insufficient balance in wallet");
			}
									}	
else {
	System.out.println("Enter Correct Password");
}
					
			}
	catch(CustomerException e) {
			System.out.println(e);
		}
		break;	
		
//---------------------------------------------Print Transaction---------------------------------//	

case 7:
				try {
				System.out.println("Enter Mobile no.");
				String mobno= sc.next();
				Customer cust=service.getMobno(mobno);
			if(cust==null) {
				throw new CustomerException("\n ---------------------\n Enter Correct Registered Mobile no ..\n ---------------------\n");}
			else {
			    System.out.println("Enter your Password");
				String pwd = sc.next();
					if(cust.getPword().equals(pwd)) {
				System.out.println(service.printTransaction(mobno));
				
				ArrayList<Transaction> tList =service.printTransaction(mobno);
				
				int count=1;
				System.out.println("----- \t --------------\t ------\t ----------\t ----------------\t -------------------");
				System.out.println("count \t Transaction Id\t Amount\t Mobile No.\t Transaction Date\t Transaction Type");
				System.out.println("----- \t --------------\t ------\t ----------\t ----------------\t -------------------");


				for(Transaction trans : tList) {
					
					System.out.println(count+"\t "+trans.getTransactionid()+"\t\t "+trans.getAmount()+"\t "+trans.getMobno()+"\t "+trans.getTranDate()+"\t\t "+trans.getTrantype());
					count++;
				}
				System.out.println("----- \t --------------\t ------\t ----------\t ----------------\t -------------------");

				}
					else {
						System.out.println("Please enter correct password");
					}
			}
				}
			
				catch (CustomerException e) {
					System.out.println(e.getMessage());
				}
					
				
		break;	
				
//---------------------------------------------Exit---------------------------------//	
				
			case 8:
				System.exit(0);
	
		
	
	
		
				}
				
				}while(option != 8);
				}
			}



