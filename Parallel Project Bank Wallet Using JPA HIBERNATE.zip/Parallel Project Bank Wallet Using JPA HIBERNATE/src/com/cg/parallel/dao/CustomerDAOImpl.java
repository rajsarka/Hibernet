package com.cg.parallel.dao;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;


import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.exception.CustomerException;

import com.cg.parallel.util.JPAUtil;


public class CustomerDAOImpl implements CustomerDAO{

	EntityManager em=null;
	EntityTransaction tran=null;
	public CustomerDAOImpl()
	{
		
	}

	public Customer AddCustomer(Customer cus) throws CustomerException {
	
	em=JPAUtil.getentityManager();
	
	//get tran object
	tran=em.getTransaction();
	
	//begin the tran
	tran.begin();
	
	em.persist(cus);
	tran.commit();
	System.out.println("Data is inserted in the table");
	Customer c1=em.find(Customer.class,cus.getMobileno());
	return c1;
	}

	@Override
	public ArrayList<Customer> getCustomerList() throws CustomerException {

		String myQry="SELECT cus FROM Customer cus "; 
	
		em=JPAUtil.getentityManager();
		TypedQuery<Customer> tyQry=em.createQuery(myQry, Customer.class);
		ArrayList<Customer> cusList=(ArrayList<Customer>)tyQry.getResultList();
		
		return cusList;
	
	}

	@Override
	public Customer showBalance(String mobileno) throws CustomerException {
		em=JPAUtil.getentityManager();
		Customer e1=em.find(Customer.class, mobileno);
		return e1;
		
	}

	@Override
	public Customer addMoney(String mobno, long amt) throws CustomerException {
		String tranType="Credited";
		long updatedBal=0;
		em=JPAUtil.getentityManager();
		tran=em.getTransaction();
		Customer cus=em.find(Customer.class, mobno);
		updatedBal=cus.getAmount()+amt;
		cus.setAmount(updatedBal);
		tran.begin();
		em.merge(cus);
		tran.commit();
		System.out.println("Balance "+amt+" is Credited for: "+mobno);
		insertTransactions(mobno, amt, tranType);
		return cus;
	}

	public void insertTransactions(String mobno, long amt, String tranType) {
		
		
		em=JPAUtil.getentityManager();
		tran=em.getTransaction();
		tran.begin();
		Transaction transac=new Transaction();
		transac.setMobno(mobno);
		transac.setAmount(amt);
		transac.setTrantype(tranType);
		transac.setTranDate(Date.valueOf(LocalDate.now()) );
		em.persist(transac);
		
		tran.commit();
		System.out.println("Data is inserted in the table");
		
	
	
	
	}
	

	@Override
	public Customer withdraw(String mobno, long amt) throws CustomerException {
		
		String tranType="Credited";
		long updatedBal=0;
		em=JPAUtil.getentityManager();
		tran=em.getTransaction();
		Customer cus=em.find(Customer.class, mobno);
		updatedBal=cus.getAmount()-amt;
		cus.setAmount(updatedBal);
		tran.begin();
		em.merge(cus);
		tran.commit();
		System.out.println("Balance "+amt+" is Credited for: "+mobno);
		insertTransactions(mobno, amt, tranType);
		return cus;


		
	}

	@Override
	public Customer fundTransfer(String mobno1, String mobno2, long famt) throws CustomerException {
		Customer cust=new Customer();
		addMoney(mobno2,famt);
		withdraw(mobno1, famt);	
		System.out.println("Debited Rs. "+famt+" from "+mobno1+" and credited Rs. "+famt+" to "+mobno2);
		return null;
	}
	public ArrayList<Transaction> printTransaction(String mobno) throws CustomerException{
		
		em=JPAUtil.getentityManager();
		tran=em.getTransaction();
		Customer cus1=em.find(Customer.class, mobno);
	
	
		String myQry="SELECT tra FROM Transaction tra WHERE tra.mobno=:mobno"; 
		TypedQuery<Transaction> tyQry=em.createQuery(myQry, Transaction.class);
		tyQry.setParameter("mobno", mobno);
		ArrayList<Transaction> tranList=(ArrayList<Transaction>)tyQry.getResultList();
	
	
		
		return tranList;
		
	}

	@Override
	public Customer getMobno(String mobno) throws CustomerException {
		em=JPAUtil.getentityManager();
		Customer e1=em.find(Customer.class, mobno);
		return e1;
		
	}

	

}
