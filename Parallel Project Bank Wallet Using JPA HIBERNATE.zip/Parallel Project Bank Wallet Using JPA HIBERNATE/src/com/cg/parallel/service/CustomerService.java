package com.cg.parallel.service;

import java.util.ArrayList;

import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.dao.CustomerDAO;
import com.cg.parallel.exception.CustomerException;



public interface CustomerService {


	

	
	
	public Customer AddCustomer(Customer cus) throws CustomerException;
	
	public ArrayList<Customer> getCustomerList() throws CustomerException;
	
	public Customer showBalance(String mobileno) throws CustomerException;

	public Customer addMoney(String mobno, long amt) throws CustomerException ;
	
	public Customer withdraw(String mobno,long  amt) throws CustomerException;
	
	public Customer fundTransfer(String mobno1,String mobno2,long famt) throws CustomerException;

	public ArrayList<Transaction> printTransaction(String mobno) throws CustomerException;
		
	public Customer getMobno(String mobno) throws CustomerException;

	

}
