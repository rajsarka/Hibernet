package com.cg.parallel.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomerServiceValidator {
	public boolean getValidateName(String name) {

		if(name == null)
			throw new NullPointerException();
		
		Pattern pat = Pattern.compile("^[A-Z][a-z]{2,21}$");
		Matcher mat = pat.matcher(name);
		if(mat.matches())
			return true;
		else
			return false;
	}
	
	public boolean getValidateMobNo(String mobno) {
		if(mobno==null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher mat = pat.matcher(mobno);
		if(mat.matches())
			return true;
		else
			return false;
	}
	
	public boolean getValidateAccNo(String acc) {

		if(acc == null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[0-9]{6}");
		Matcher mat = pat.matcher(acc);
		if(mat.matches())
			return true;
		else
			return false;
	}
	
	public boolean getValidateBankName(String bankname) {

		if(bankname == null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[A-Za-z]{3,21}$");
		Matcher mat = pat.matcher(bankname);
		if(mat.matches())
			return true;
		else
			return false;
	}
	
	public boolean getValidatePassword(String pword) {

		if(pword== null)
			throw new NullPointerException();
		Pattern pat = Pattern.compile("^[A-Za-z]{3}[^a-zA-Z0-9]{1}[0-9]{3}$");
		Matcher mat = pat.matcher(pword);
		if(mat.matches())
			return true;
		else
			return false;
	}
}
