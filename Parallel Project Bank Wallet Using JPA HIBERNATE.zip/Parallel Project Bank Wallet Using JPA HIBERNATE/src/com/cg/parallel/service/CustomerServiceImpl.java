package com.cg.parallel.service;

import java.util.ArrayList;


import com.cg.parallel.bean.Customer;
import com.cg.parallel.bean.Transaction;
import com.cg.parallel.dao.CustomerDAO;
import com.cg.parallel.dao.CustomerDAOImpl;
import com.cg.parallel.exception.CustomerException;

public class CustomerServiceImpl implements CustomerService{

CustomerDAO dao;
	
	public  CustomerServiceImpl()
	{
		dao = new CustomerDAOImpl();
	}
	
	
	
	public Customer AddCustomer(Customer cus) throws CustomerException {
	return dao.AddCustomer(cus);
		
	
	}

	public ArrayList<Customer> getCustomerList() throws CustomerException {
		return dao.getCustomerList();
		
	}



	public Customer showBalance(String mobileno) throws CustomerException {
		return dao.showBalance(mobileno);
		
	}



	@Override
	public Customer addMoney(String mobno, long amt) throws CustomerException {
		
		
			return dao.addMoney(mobno, amt);
		
	}
	
	public Customer withdraw(String mobno,long  amt) throws CustomerException {
		return dao.withdraw(mobno, amt);
	}


	public Customer fundTransfer(String mobno1,String mobno2,long famt) throws CustomerException{
		return dao.fundTransfer(mobno1, mobno2, famt);
	}

	public ArrayList<Transaction> printTransaction(String mobno) throws CustomerException{
		return dao.printTransaction(mobno);
	}

	public Customer getMobno(String mobno) throws CustomerException{
		return dao.getMobno(mobno);
	}




}
