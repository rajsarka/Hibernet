package com.cg.demo.bean;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table
@DiscriminatorValue("MGR")
public class Manager extends Employee
{



	private String deptname;

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) 
	{
		this.deptname = deptname;
	}


	
	public Manager(int empId, String empName, int empSal, String deptname) {
		super(empId, empName, empSal);
		this.deptname = deptname;
	}

	public Manager() {
		super();
		
	}

	@Override
	public String toString() {
		return "Manager [deptname=" + deptname + ", getDeptname()=" + getDeptname() + ", getEmpName()=" + getEmpName()
				+ ", getEmpId()=" + getEmpId() + ", getEmpSal()=" + getEmpSal() + ", toString()=" + super.toString()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + "]";
	}


	
	
}
