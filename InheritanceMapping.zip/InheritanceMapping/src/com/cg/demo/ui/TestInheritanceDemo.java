package com.cg.demo.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Employee;
import com.cg.demo.bean.Manager;
import com.cg.demo.util.JPAUtil;

public class TestInheritanceDemo {
	public static void main(String[] args) {
		
		EntityManager em=JPAUtil.getentityManager();
		EntityTransaction tran=em.getTransaction();
		
		
		//create one employee
				Employee employee1 = new Employee();
				employee1.setEmpName("John");
				employee1.setEmpSal(5000);
			
		//create 2nd employee		
				Employee employee2 = new Employee();
				employee2.setEmpName("Rajib");
				employee2.setEmpSal(35000);
				
				
				
		//create one manager
				Manager manager = new Manager();
				manager.setEmpName("Trisha");
				manager.setEmpSal(8000);
				manager.setDeptname("java");
				
				tran.begin();
				em.persist(employee1);
				em.persist(employee2);
				em.persist(manager);
				tran.commit();
				System.out.println("Data is added");
		
		
	}
}
