package src.com.cg.demo.service;

import java.util.ArrayList;



import src.com.cg.demo.bean.Author;
import src.com.cg.demo.bean.Book;
import src.com.cg.demo.dao.DAOImpl;
import src.com.cg.demo.dao.IDao;

public class ServiceImpl implements IService {

	IDao dao=null;
	public ServiceImpl()
	{
		dao=new DAOImpl();
	}
	
	@Override
	public Book addBook(Book book) {
		
		return dao.addBook(book);
	}

	@Override
	public ArrayList<Author> getAllBook() {
		
		return dao.getAllBook();
	}

	@Override
	public ArrayList<Book> getFewBooks() {
		
		return dao.getFewBooks();
	}

	@Override
	public Author getAuthors(int isbn) {
		
		return dao.getAuthors(isbn);
	}

}
