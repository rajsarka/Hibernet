package src.com.cg.demo.dao;



import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import src.com.cg.demo.bean.Author;
import src.com.cg.demo.bean.Book;
import src.com.cg.demo.util.JPAUtil;

public class DAOImpl implements IDao{
	EntityManager em=null;
	EntityTransaction tran=null;

	public DAOImpl()
	{
		em=JPAUtil.getentityManager();
		tran=em.getTransaction();
	}


	public Book addBook(Book book)
	{
		tran.begin();
		em.persist(book);
		tran.commit();
		System.out.println("Data is inserted in the table");
		
		return book;
		
	}

	public ArrayList<Author> getAllBook()
	{
	
		//String myQry="SELECT boos FROM Book boos "; 
	Query tyQry=em.createQuery("SELECT boos FROM Book boos");
		ArrayList<Author> bookList=(ArrayList)tyQry.getResultList();
	
		return bookList;
	}
	
	public ArrayList<Book> getFewBooks()
	{
	TypedQuery<Book> tq=em.createQuery("SELECT ords FROM Book ords where price between 500 and 1000",Book.class);	
	ArrayList bookList=(ArrayList<Book>)tq.getResultList();	
		return bookList;
	}
	
	public Author getAuthors(int isbn) {
		em=JPAUtil.getentityManager();
		Author e1=em.find(Author.class, isbn);
		return e1;
	}



}
