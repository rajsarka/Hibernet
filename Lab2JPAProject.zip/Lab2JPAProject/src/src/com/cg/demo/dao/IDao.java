package src.com.cg.demo.dao;

import java.util.ArrayList;

import src.com.cg.demo.bean.Author;
import src.com.cg.demo.bean.Book;

public interface IDao {

	public Book addBook(Book book);
	
	public ArrayList<Author> getAllBook();
	
	public ArrayList<Book> getFewBooks();
	
	public Author getAuthors(int isbn);
}
