package src.com.cg.demo.ui;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;


import src.com.cg.demo.bean.Author;
import src.com.cg.demo.bean.Book;
import src.com.cg.demo.dao.DAOImpl;

public class Test {

	public static void main(String args[]) {
		
		DAOImpl dao=new DAOImpl();
		Scanner sc=new Scanner(System.in);
		int option;
		
		do {
			Author Author1= new Author();
			Book Book1=new Book();
			System.out.println("1.Add Author and Book Details");
			System.out.println("2.get All books");
			System.out.println("3.Get All Books Writtn by given Author name");
			System.out.println("4.List all books with given price range between Rs. 500 to 1000");		
			System.out.println("5.List the author name for given book id. ");
			
			
			option=sc.nextInt();
			
			switch(option){
				
				case 1:
					System.out.println("Enter author name");
					String authn=sc.next();
					System.out.println("Enter Title of the Book");
					String title=sc.next();
					System.out.println("Enter Price of the  Book");
					int price=sc.nextInt();
					
					Author1.setName(authn);
					Book1.setTitle(title);
					Book1.setPrice(price);
					
					HashSet<Author> firstOrderProdSet=new HashSet();
					firstOrderProdSet.add(Author1);
					Book1.setAuthors(firstOrderProdSet);
					dao.addBook(Book1);
					System.out.println("----------------");
					break;
			
				case 2:
//					ArrayList<Book> eList =dao.getAllBook();
//					for(Book tempBooks:eList)
//					{
//						System.out.println("Book Name: "+tempBooks.getTitle()+" / Book Price : "+tempBooks.getPrice()+"/ Author Name: "+tempBooks.getAuthors());
//					}
//					System.out.println("----------------");
					
					ArrayList<Author> b=(ArrayList<Author>) dao.getAllBook();
					System.out.println(b);
					break;	
			
			
				case 3:
					
					System.out.println(dao.getFewBooks());
			break;
			
			}
				
			}while(option!=4);
			
			
			
			
	}
			
			
			
			
		}
//		Author Author1= new Author();
//		Author1.setName("Nazrul");
//
//
//		Author Author2 = new Author();
//		Author2.setName("Kanitkar");
//
//
//		Author Author3 = new Author();
//	    Author3.setName("Rowling");
//		
//
//		Author Author4 = new Author();
//
//		Author4.setName("Herbert");
//		
//		System.out.println("----------------");
		
		
		// now define first Book and add Some Authors in it
					
//					Book firstOrder = new Book();
//					DAOImpl dao=new DAOImpl();
//					HashSet<Author> firstOrderProdSet=new HashSet();
//					firstOrderProdSet.add(Author1);
//					firstOrderProdSet.add(Author2);
//					firstOrderProdSet.add(Author3);
//					firstOrderProdSet.add(Author4);
//					
//					firstOrder.setTitle("Java");
//					firstOrder.setPrice(150);
//					
//					
//					firstOrder.setAuthors(firstOrderProdSet);
//					dao.addBook(firstOrder);
//					System.out.println("----------------");
		
// now define second Book and add Some Authors in it
					
//					Book SecondOrder = new Book();
//					DAOImpl dao=new DAOImpl();
//					HashSet<Author> SecondOrderProdSet=new HashSet();
//					SecondOrderProdSet.add(Author1);
//					SecondOrderProdSet.add(Author2);
//					SecondOrderProdSet.add(Author3);
//					SecondOrderProdSet.add(Author4);
//					
//					SecondOrder.setTitle("Python");
//					SecondOrder.setPrice(780);
//					
//					
//					SecondOrder.setAuthors(SecondOrderProdSet);
//					dao.addBook(SecondOrder);
//					System.out.println("----------------");
		
		//******Find Book whose price range is between 500 & 1000******//
//		DAOImpl dao=new DAOImpl();
//		System.out.println(dao.getFewBooks());
		
//		//******Find Author name For given Book isbn******//
//		System.out.println("Enter Book id");
//		Scanner sc=new Scanner(System.in);
//				int isbn=sc.nextInt();
//		DAOImpl dao=new DAOImpl();
//		System.out.println(dao.getAuthors(isbn));
//	}
	
	


