package src.com.cg.demo.bean;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Author_table")
public class Author {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="author_id",length=10)
	private int id;
	
	@Column(name="Author_name",length=40)
	private String name;
	
	@ManyToMany(fetch=FetchType.LAZY,mappedBy="authors")
private Set<Book> books ;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	

	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", books=" + books + ", getId()=" + getId() + ", getName()="
				+ getName() + ", getBooks()=" + getBooks() + "]";
	}

	public Author(int id, String name, Set<Book> books) {
		super();
	
		this.name = name;
		this.books = books;
	}

	public Author() {
		super();
		
	}
	
	
	
	
}
