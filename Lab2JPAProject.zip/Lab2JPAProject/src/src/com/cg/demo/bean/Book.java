package src.com.cg.demo.bean;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="book_table")
public class Book {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ISBN",length=20)
	private int ISBN;
	
	@Column(name="Book_title",length=20)
	private String title;
	
	@Column(name="Book_price",length=5)
	private int price;
	
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="book_author",joinColumns= {@JoinColumn(name="ISBN")},inverseJoinColumns= {@JoinColumn(name="author_id")})
	
	private Set<Author> authors;

	

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	

	public Set<Author> getAuthors() {
		return authors;
	}

	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}

	


	public Book( String title, int price) {
		super();
		
		this.title = title;
		this.price = price;
		
	}

	public Book() {
		super();
		
	}
	
	
	
}
